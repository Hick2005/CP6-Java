# Projeto Biblioteca com Flyway e MySQL

Henrique Reinhardt RM 557270

## Como rodar
1. Crie o banco no MySQL:
   ```sql
   CREATE DATABASE biblioteca;
   ```

2. Ajuste o usuário e senha no arquivo `application.properties` se necessário.

3. Execute o projeto com:
   ```bash
   mvn spring-boot:run
   ```

4. O Flyway criará automaticamente as tabelas no banco MySQL.
